document.addEventListener("DOMContentLoaded", () => {
    console.log("Job Platform Phase 1 loaded successfully.");
});
