# کارراه | Job Platform

پروژه یک پلتفرم کاریابی واقعی با Django، HTML، CSS، JavaScript و دیتابیس.

## مرحله ۱

در این مرحله:
- اسکلت Django ساخته شده
- دیتابیس واقعی SQLite فعال است
- مدل‌های اولیه ساخته شده‌اند
- پنل Django Admin آماده است
- صفحه اصلی Responsive ساخته شده
- endpoint سلامت `/health/` اضافه شده
- تست‌های پایه اضافه شده‌اند

## اجرای محلی

```bash
python -m venv .venv
```

Linux/macOS:
```bash
source .venv/bin/activate
```

Windows:
```bash
.venv\Scripts\activate
```

نصب:
```bash
pip install -r requirements.txt
```

ساخت migration:
```bash
python manage.py makemigrations
python manage.py migrate
```

تست:
```bash
python manage.py test
```

اجرای سرور:
```bash
python manage.py runserver
```

صفحه:
`http://127.0.0.1:8000/`

Health check:
`http://127.0.0.1:8000/health/`

پنل مدیریت:
`http://127.0.0.1:8000/admin/`

## GitHub

مخزن را بساز و تمام فایل‌های این پروژه را در ریشه Repository قرار بده.

سپس در محیطی مثل GitHub Codespaces:

```bash
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py test
python manage.py runserver 0.0.0.0:8000
```

## نکته تولید

SQLite برای توسعه و تست اولیه استفاده شده است. قبل از انتشار عمومی، PostgreSQL را به عنوان دیتابیس اصلی متصل می‌کنیم.
