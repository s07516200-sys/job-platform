from django.db import models

class SiteSetting(models.Model):
    site_name = models.CharField(max_length=120, default="کارراه")
    tagline = models.CharField(max_length=255, blank=True)
    support_phone = models.CharField(max_length=30, blank=True)
    support_email = models.EmailField(blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.site_name

class JobCategory(models.Model):
    name = models.CharField(max_length=120, unique=True)
    slug = models.SlugField(max_length=140, unique=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]
        verbose_name = "دسته‌بندی شغل"
        verbose_name_plural = "دسته‌بندی‌های شغل"

    def __str__(self):
        return self.name
