from django.test import TestCase
from django.urls import reverse
from .models import JobCategory, SiteSetting

class CoreTests(TestCase):
    def test_home_page(self):
        response = self.client.get(reverse("home"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "کارراه")

    def test_health_endpoint(self):
        response = self.client.get(reverse("health"))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["status"], "ok")

    def test_category_model(self):
        category = JobCategory.objects.create(
            name="برنامه‌نویسی",
            slug="programming",
        )
        self.assertEqual(str(category), "برنامه‌نویسی")

    def test_site_setting_model(self):
        setting = SiteSetting.objects.create(site_name="کارراه")
        self.assertTrue(setting.is_active)
